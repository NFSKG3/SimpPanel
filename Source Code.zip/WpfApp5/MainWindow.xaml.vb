﻿Class MainWindow
    Private Sub Button_Click(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\appwiz.cpl")
    End Sub

    Private Sub Button_Click_1(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\timedate.cpl")
    End Sub

    Private Sub Button_Click_2(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\irprops.cpl")
    End Sub

    Private Sub Button_Click_3(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\inetcpl.cpl")
    End Sub

    Private Sub Button_Click_4(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\wscui.cpl")
    End Sub

    Private Sub Button_Click_5(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\sysdm.cpl")
    End Sub

    Private Sub Button_Click_6(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\TabletPC.cpl")
    End Sub

    Private Sub Button_Click_7(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\Speech\SpeechUX\sapi.cpl")
    End Sub

    Private Sub Button_Click_8(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\telephon.cpl")
    End Sub

    Private Sub Button_Click_9(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\desk.cpl")
    End Sub

    Private Sub Button_Click_10(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\powercfg.cpl")
    End Sub

    Private Sub Button_Click_11(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\main.cpl")
    End Sub

    Private Sub Button_Click_12(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\ncpa.cpl")
    End Sub

    Private Sub Button_Click_13(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\intl.cpl")
    End Sub

    Private Sub Button_Click_14(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\Firewall.cpl")
    End Sub

    Private Sub Button_Click_15(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\bthprops.cpl")
    End Sub

    Private Sub Button_Click_16(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\joy.cpl")
    End Sub

    Private Sub Button_Click_17(sender As Object, e As RoutedEventArgs)
        MsgBox("Programmed fully by Lennon Craig. Created with Microsoft Visual Studio Community 2017.")
    End Sub

    Private Sub Button_Click_18(sender As Object, e As RoutedEventArgs)
        System.Diagnostics.Process.Start("C:\Windows\System32\mmsys.cpl")
    End Sub

    Private Sub Button_Click_19(sender As Object, e As RoutedEventArgs)

    End Sub

    Private Sub Button_Click_20(sender As Object, e As RoutedEventArgs)
        MsgBox("This program may seem pointless at first, but it is indeed useful. How? Well, domains may disable accsess to the normal Control Panel GUI. However, you can open the .cpl files yourself (this program does that) and accsess the control panel items. However, you have to remember exact filenames and what they do. This simplifies that into a easy-to-use GUI.")
    End Sub
End Class
